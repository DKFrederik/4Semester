<?php
$page_content = '/WebPages/ContentPages/404Content.php';
include '../Index.php';

