<?php
$page_content = 'WebPages/ContentPages/LoginContent.php';
include '../Index.php';
