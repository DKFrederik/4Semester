<?php
$page_content = '/WebPages/ContentPages/AboutContent.php';
include '../Index.php';
