<?php

$page_content = 'WebPages/ContentPages/CalendarContent.php';
include '../Index.php';
