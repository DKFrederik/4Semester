<?php
class clsWSSEToken { 
        private $UsernameToken; 
        function __construct ($innerVal){ 
            $this->UsernameToken = $innerVal; 
        } 
}