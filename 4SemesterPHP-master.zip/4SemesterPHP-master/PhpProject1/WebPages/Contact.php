<?php
$page_content = 'WebPages/ContentPages/ContactContent.php';
include '../Index.php';
