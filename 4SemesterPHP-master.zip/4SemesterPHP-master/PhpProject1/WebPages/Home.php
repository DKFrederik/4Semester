<?php 
$page_content = '/ContentPage/HomeContent.php';
include('../Index.php');