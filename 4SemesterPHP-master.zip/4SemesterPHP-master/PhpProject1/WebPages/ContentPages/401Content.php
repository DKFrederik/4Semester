<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <div class="jumbotron">
            <div class="container">
                <h1>401, Not authorized</h1>
                <hr />
                <p><a class="btn btn-primary" href="Index.php" role="button">Ta' mig til startsiden! &raquo;</a></p>
            </div>
        </div>
      <hr />
    </body>
</html>

