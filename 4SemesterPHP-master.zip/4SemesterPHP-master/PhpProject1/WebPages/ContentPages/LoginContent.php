<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Log Ind</title>
    </head>
    <body>
        <div class="container homepage">
            <h1>Log in</h1>
            <form action="Helpers/LoginAction.php" method="POST">    
                Brugernavn: <input type="text" name="username" /><br /><br />
                Adgangskode: <input type="text" name="password" /><br />
                <input type="submit" value="Log Ind">
            </form>
            <p class="lead blog-description text-center">ASLASLD SADSAKLDH AKJSDHA SLKJDJSAD LASDHASLKJD HASDKLJSAHA SKDKSAJDH </p>
        </div>
    </body>
</html>
