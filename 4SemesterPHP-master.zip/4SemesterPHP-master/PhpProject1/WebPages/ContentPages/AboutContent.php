<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Om klubben</title>
    </head>
    <body>
        <div class="jumbotron">
            <div class="container homepage">
                <h1>This is about about</h1>
                <p class="lead blog-description text-center">ASLASLD SADSAKLDH AKJSDHA SLKJDJSAD LASDHASLKJD HASDKLJSAHA SKDKSAJDH </p>
            </div>
        </div>

    </body>
</html>
