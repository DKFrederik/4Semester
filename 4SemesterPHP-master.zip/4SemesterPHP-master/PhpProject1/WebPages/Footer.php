<footer>
    <p>&copy; 2015 Company, Inc.</p>
</footer>