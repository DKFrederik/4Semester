<?php
include_once 'ContentInfo.php';
/**
 * Description of News
 *
 * @author Nichlas
 */
class News extends ContentInfo{
    var $Picture;
}
