<?php
include_once 'ContentInfo.php';
/**
 * Description of Events
 *
 * @author Nichlas
 */
class Events {
    var $StartTime;
    var $EndTime;
    var $EventType;
}
