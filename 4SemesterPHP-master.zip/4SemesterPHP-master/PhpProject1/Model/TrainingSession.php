<?php
include_once 'Events.php';
/**
 * Description of TrainingSession
 *
 * @author Nichlas
 */
class TrainingSession {
    var $Trainer;
}
