<?php
include_once 'Events.php';
/**
 * Description of Match
 *
 * @author Nichlas
 */
class Match {
    var $Team;
    var $Opponent;
    var $HomeGoal;
    var $AwayGoal;
}
