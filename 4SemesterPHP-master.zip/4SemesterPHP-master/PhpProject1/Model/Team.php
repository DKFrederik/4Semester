<?php
/**
 * Description of Team
 *
 * @author Nichlas
 */
class Team{
    var $Id;
    var $Name;
    var $Type;
    var $Players;
}
