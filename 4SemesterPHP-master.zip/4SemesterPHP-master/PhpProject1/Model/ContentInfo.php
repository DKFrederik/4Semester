<?php
/**
 * Description of ContentInfo
 *
 * @author Nichlas
 */
class ContentInfo {
    var $Title;
    var $Author;
    var $Date;
    var $Content;
    var $IsPublic;
    var $ContentType;
}
